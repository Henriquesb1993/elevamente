# Elevamente — Programa Melhora do Operador

Sistema web para acompanhamento de operadores com baixo desempenho através de mentoria.

## Funcionalidades

- 📊 **Dashboard** — KPIs, gráficos de evolução, agenda do dia, tratativas pendentes
- 👥 **Operadores** — Lista completa com filtros, busca, status de mentoria e resultado
- 📋 **Ficha do Operador** — Timeline de eventos, perda financeira calculada, relatório PDF
- 💬 **Mentoria** — Formulário em 4 etapas, lista de sessões, exportação Excel
- 📅 **Agenda** — Visão semana/lista/calendário, agendamento, controle de presença
- 🔁 **Tratativas** — Kanban por status, modal de retorno do setor, exportação Excel
- 📊 **Relatórios** — Rankings, causas, evolução, exportação Excel completo + PDF
- ⚙️ **Parâmetros** — Custos financeiros por função (MOT/COB/FISC/COORD)
- 🗃️ **Base de Dados** — Upload de planilha Excel com processamento automático
- 🔐 **Login** — Perfis de acesso por setor (Gestor, RH, Psicologia, DP, Ambulatório)

## Como rodar

```bash
npm install
npm run dev
```

Acesse em: http://localhost:5173

## Credenciais de demonstração

| Usuário | Senha | Perfil |
|---------|-------|--------|
| `gestor` | `eleva@2025` | Gestor Geral — acesso total |
| `rh` | `rh@2025` | Recursos Humanos |
| `psicologia` | `psi@2025` | Psicologia |
| `dp` | `dp@2025` | Departamento Pessoal |
| `ambulatorio` | `amb@2025` | Ambulatório |
| `g1` | `g1@2025` | Gestor Garagem G1 |
| `g2` | `g2@2025` | Gestor Garagem G2 |

## Tecnologias

- **React 18** + Vite
- **Recharts** — gráficos
- **SheetJS (XLSX)** — leitura de planilhas Excel (carregado dinamicamente)
- **jsPDF + AutoTable** — exportação PDF (carregado dinamicamente)

## Base de dados (Excel)

A planilha deve conter as seguintes abas:

| Aba | Conteúdo |
|-----|---------|
| `QUERY_PRONTUARIO` | Histórico de eventos (F=Falta, M=Multa, S=Suspensão...) |
| `QUERY_MULTAS` | Autos de infração SPTrans |
| `ACIDENTES` | Acidentes com parecer de responsabilidade |
| `QUADRO_FUNC` | Dados cadastrais dos funcionários |
| `LISTA PRESENÇA ELEVAMENTE` | Presenças em mentorias |
| `FORMULÁRIO DE MENTORIA` | Respostas do formulário |

## Deploy (Vercel)

```bash
npm run build
# Faça upload da pasta dist no Vercel, Netlify ou qualquer hosting estático
```

---

Desenvolvido para o Programa Elevamente — Uso interno.
